package com.ryanhideo.linebot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinebotBridgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
